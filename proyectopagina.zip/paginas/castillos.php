<?php
	
    $servername = "127.0.0.1";
    $database = "Proyecto";
    $username = "alumno";
    $password = "alumnoipm";
    
    $conexion = mysqli_connect($servername, $username, $password, $database); // se crea la conexion


    if (!$conexion) {
        die("Conexion fallida: " . mysqli_connect_error());
    }
    else{
        //insertamos el resultado del formulario

        //seleccionamos todas las filas que haya en usuarios
		$resultado = mysqli_query($conexion,"select * from Elementos where idElementos = 1;");
        $fila=mysqli_fetch_assoc($resultado);
        $fotos = mysqli_query($conexion,"select Ruta from Fotos where Elementos_idElementos = 1;");

    }
    mysqli_close($conexion);
?>
<!DOCTYPE html>



<html lang="en">
    <head>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width= device-width= inicial-scale=1.0">
        <title> De castillos y Reyes </title>
        <link rel="stylesheet" type="text/css" href="../estilos/CivilizacionesAmerica 1.css" />
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css">


        
    </head>
    
   
    <body>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
        <header>
            <nav class="navbar" id="Navbar">
                
                
                <a href="./Estructura%20de%20la%20pagina(CON%20DRROPBck) 1.html"><img src="../imagenes/Logo para la pagina (Cargar este).png"width="160"height="80"/></a>
            
<br>
<br>
<br>
<div class="dropdown">
    <button class="dropbtn">Castillos del mundo</button>
    <div class="dropdown-content">
    <a href="./castillos.php ">Castillos de Europa</a>
    <a href="">Castillos de Africa</a>
    <a href="">Castillos de Asia</a>
    <a href="">Castillos de sudeste asiatico</a>
    <a href="">Castillos de America</a>
        </div>
</div>
<div class="dropdown">
    <button class="dropbtn">Civilizaciones</button>
    <div class="dropdown-content">
    <a href="">Civilizaciones de Europa</a>
    <a href="">Civilizaciones de Africa</a>
    <a href="../index.html/Civilizaciones de asia.html">Civilizaciones de Asia</a>
    <a href="">Civilizaciones del sudeste asiatico</a>
    <a href="../index.html/CivilizacionesAmerica.html">Civilizaciones de America</a>
        </div>
</div>
<div class="dropdown">
    <button class="dropbtn">Soldados medievales</button>
    <div class="dropdown-content">
    <a href="">Tropas basicas</a>
    <a href="">Equipo de asedio</a>
    <a href="">Armas, y su produccion</a>
    <a href="">Tropas regionales</a>
        </div>
</div>
<div class="dropdown">
    <button class="dropbtn">Batallas Medievales</button>
    <div class="dropdown-content">
    <a href="">Batallas a campo abierto</a>
    <a href="">Asedios</a>
    <a href="">Batallas historicas</a>
    <a href="">Guerras historicas</a>
        </div>
</div>
<div class="dropdown">
    <button class="dropbtn">Mas sobre</button>
    <div class="dropdown-content">
    <a href="">Maravillas medievales</a>
    <a href="">Las Cruzadas</a>
    <a href="">Reyes y figuras historicas</a>
    <a href="../index.html/Juegos Medievales.html">Juegos medievales</a>
    <a href="">Acerca de...</a>
        </div>
</div>
            </nav>
        </header>
        <nav>
            <div class="linea">
            
            
        </nav>

<div class="slider-frame">

<ul>
<?php 
while(        $arregloFotos=mysqli_fetch_assoc($fotos)){?>
<li><img src="<?php echo $arregloFotos["Ruta"]?>" width="1286.4px" height="625" alt=""></li>
<?php
}
?>



</ul>

</div>

 <br>
 <br>
 <br>
 <h1><?php echo $fila["Nombre"]?></h1>

 

 <div class="container">
  <input type="text" placeholder="Buscar">
  <div class="btn">
    <i class="fa fa-search"></i>
  </div>
</div>

<div class="texto2">
    <div class="texto2 p">

      <br>
      

<p><?php echo $fila["Introduccion"]?></p> 


<br>
<br>
<?php echo $fila ["descripcion"];
if($fila["Categoria"]=="Civilizaciones"){?>

<h3>Aztecas</h3>    

<br>
<p>Los orígenes de los Aztecas se remonta desde principios del siglo XII hasta el año 1325 aproximadamente, cuando para entonces, eran conocidos como los mexicas, un pueblo nómada que se asentó en el valle de México y poco a poco comenzó su expansión hasta que, luego de 200 años gobernaron y colonizaron la región central mesoamericana en una triple alianza entre los pueblos de Texcoco (acolhuas), Tlacopan (tepanecas) y México-Tenochtitlán. De hecho, Tenochtitlán fue la capital del Imperio completo. Desde allí se expandieron hacia afuera, se adueñaron de los actuales estados de México, Veracruz, Puebla, Oaxaca, Guerrero, Chiapas (la costa), Hidalgo y parte del territorio actual de Guatemala. Era una sociedad que por encima de todo valoraba la destreza de los guerreros, lo que le proporcionó una ventaja frente a las tribus rivales de la zona. A finales del siglo XV, los aztecas controlaban la totalidad del centro de México, formando un imperio militar que obligaba a sus rivales a pagar tributos.</p>
<br>
<br>
 <img src="../imagenes/aztecas_y_mayas_diferencias_principales_2021_orig.jpg" width="1286.4px" height="625" alt="mapa de la expansión de los aztecas">
 <br>
 <br>
   <p> La cultura azteca se consolidó a partir de la experiencia de aquellos que llegaron antes, pero ella misma creó pocas novedades. Poseían una agricultura avanzada que servía de sustento a una enorme población. Construyeron edificios inmensos de diseño grandioso y destacaron en diferentes ramas del arte. Trabajaban bien los metales, de hecho, Dominaban un tipo de metalurgia prehispánica basada en bronce, oro, plata y obsidiana, con el que confeccionaban ornamentos y armas para la guerra, aunque no conocían el hierro o el acero. Al no poseer ningún animal de tracción adecuado, no emplearon la rueda como elemento motriz. Su carácter belicista se reflejaba en sus vestimentas, adornadas con plumas y otros adornos que mostraban además la jerarquía del individuo dentro de la sociedad. Poseían también una escritura pictográfica que cumplía fines de documentación, un sistema métrico propio con el que desarrollaron numerosas obras arquitectónicas, y un sistema astronómico basado en la observación del Sol, la Luna y Venus</p>
   <br>
   <br>
    <img src="../imagenes/aztecas 1.png"width="1286.4px" height="625">
    <br>
    <br>
    <p>Una de las principales características que distinguía a la cultura azteca era su afición por los sacrificios. La mitología azteca establecía que debía alimentarse al sol con sangre humana para darle fuerza y que amaneciera todos los días. Los sacrificios humanos se realizaban a gran escala; varios miles de ellos en un mismo día era algo habitual. En ocasiones las víctimas eran decapitadas o despellejadas, arrancándoseles el corazón cuando aún estaban vivas. Los sacrificios se llevaban a cabo en lo alto de enormes pirámides, para estar más cerca del sol, por lo que la sangre se derramaba por los escalones. Aunque la economía azteca se basó principalmente en el maíz, pensaban que los cultivos dependían de la provisión regular de la sangre de los sacrificios. Es también por eso que la mayoría de los Aztecas eran guerreros natos, ya que para conseguir victimas para los sacrificios, debían atacar pueblos y aldeas cercanas, tanto mayas como aztecas, para capturar a su gente y volverlos prisioneros para luego sacrificarlos o volverlos esclavos para sus cultivos.</p>
    <br>
    <br>
    <img src="../imagenes/guerreros-aztecas-ataviados-con-sus-armas-y-vestimenta-tipicas_df905ca0_1280x720.jpg"width="1286.4px" height="625">
    <br>
    <br>
    <p>La demanda incesante de víctimas para sacrificios propició que los aztecas no ejercieran demasiado control en las ciudades satélite, pues al facilitar las frecuentes revueltas tenían una oportunidad para capturar nuevas víctimas. En épocas de paz, se organizaban "guerras florales", como competencias de valor y de artes bélicas, o con el objetivo de obtener víctimas. Luchaban con palos de madera cuyo fin no era matar al rival, sino mutilarlo y dejarle inconsciente. Si la lucha era a muerte, incrustaban cuchillas de obsidiana en los palos.</p>
    <br>
    <br>
    <img src="../imagenes/IYM2ZJAYDNBU7JXRU3BBVOTMTA.avif"width="1286.4px" height="625">
    <br>
    <br>
    <p>A pesar de su importante agricultura y del desarrollo de las artes, vista desde hoy la sociedad de los aztecas no parecía tener futuro. No aportaron ninguna tecnología significativa, ni ideas religiosas o teorías políticas de importancia. Esta civilización terminó repentinamente con la llegada de los españoles, a principios del siglo XVI. La sociedad azteca, afectada por enfermedades europeas transmitidas por los primeros comerciantes, se desmoronó definitivamente al enfrentarse a un pequeño ejército español equipado con armas de acero, armas de fuego y unos cuantos caballos (que por cierto, ninguna civilización americana conocía el caballo). La crueldad de los aztecas contribuyó a su declive, ya que los españoles no tuvieron ninguna dificultad en contar con la ayuda de las otras tribus de México que se oponían o querían salvarse de la sed de sangre y sacrificios de los aztecas.</p>   
    <br>
    <br>
    <iframe width="746.4" height="400" src="https://www.youtube.com/embed/SuXJ7Gem3Ok?si=1upFPe6p4qGmHGT6" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
    <br>
    <br>
    <a href="https://www.youtube.com/@MemoriasDePez">Creditos a Memorias De Pez</a>
<br>
<br>


    <h3>Mayas</h3>
    
<br>
<p>Los mayas fueron un conjunto de los pueblos precolombinos que gobernaron Mesoamérica durante 18 siglos, y como todas, esta fue una tribu nómada en sus inicios que se asentó y construyo una civilización. ellos ocuparon la península de Yucatán, Belice, Honduras y Guatemala. Su origen se remonta probablemente al segundo milenio a.C., aunque alcanzó su apogeo entre los años 600 y 900 d.C. A pesar de que se asentaron en tierras de escaso valor agrícola, crearon monumentos y centros de ceremonias casi tan impresionantes como los erigidos en Egipto. los mayas Fueron una de las civilizaciones más destacadas en la América originaria toda. Dejaron tras de sí un conjunto importante de ruinas y un legado cultural que inspiró a las culturas posteriores, parte del cual aún sobrevive.</p>                                                                   
<br>
<br>
<img src="../imagenes/Antiguas ciudades mayas estaban plagadas de mercurio.jpg"width="1286.4px" height="625">
<br>
<br>
<p>Los mayas son recordados principalmente por su cultura, arquitectura, idioma y religión. inventaron el único sistema completo de escritura de América precolombina, y desarrollaron un conocimiento propio en materia artística, arquitectónica, matemática, astronómica y ecológica. Entre otras cosas, se les atribuye la invención del cero. También, a pesar de no poseer un gran avance tecnológico, ni una arquitectura moderna lograron crear monumentos que resultan incluso hasta el día de hoy, impresionantes, poseían una religión extraña y un lenguaje único, el K’iche’, un idioma maya hablado en el sur de Guatemala. En la actualidad se conservan tres códices de la civilización maya, restos de un elevado número destruido por los europeos, quienes temían que contuvieran herejías.</p>
<br>
<br>
<img src="../imagenes/civilizacion-maya.jpg"width="1286.4px" height="625">
<br>
<br>
<p>Ante ellos, los propios antepasados difuntos y los chamanes servían de intermediarios. Por eso los mayas enterraban a sus muertos debajo de los pisos de sus casas, en medio de las correspondientes ofrendas, acordes a su estatus social.</p>
<br>
<br>
<img src="../imagenes/los-dias-de-gloria-del-imperio-maya-9-900x900.webp" width="1286.4px" height="625">
<br>
<br>
<p>La cosmovisión maya era altamente elaborada: contemplaba 13 niveles en el cielo y nueve en el inframundo, y entre los dos se hallaba el mundo de los vivos. A su vez, cada nivel constaba de cuatro puntos cardinales, cada uno asociado a un color distintivo, y a los cuales estaban asociados ciertos aspectos de las deidades principales de su panteón.</p>
<br>
<br>
<img src="../imagenes/cultura-maya-mesoamerica-precolombino-historia-mexico-e1567715881268.jpg"width="1286.4px" height="625">
<br>
<br>
<p>Por lo demás, la religión estaba en manos de los sacerdotes, un grupo cerrado cuyos miembros provenían de la élite de la sociedad. Durante el Período Clásico, comenzó a surgir entre ellos el sumo sacerdote y conductor de la sociedad, que hacía las veces también de gobernante.</p>
<br>
<br>
<img src="../imagenes/imperio-maya--efe-compressor.jpg"width="1286.4px" height="625">
<br>
<br>
<p>La civilización maya comenzó a decaer en el siglo X, tal vez a causa de un terremoto o una erupción volcánica en la zona. Muchas de las construcciones ceremoniales se abandonaron a partir de entonces. Los guerreros del centro de México invadieron este territorio y se agruparon en pequeñas comunidades en el bosque pluvial. El último centro maya sucumbió a manos de los españoles en el siglo XVII, pero actualmente hay más de dos millones de descendientes mayas en la península de Yucatán, Guatemala y Belice.</p>
<br>
<br>
<iframe width="746.4" height="400" src="https://www.youtube.com/embed/g00IZe-31gI?si=IlOtFA8XfYLdcXKR" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
<br>
<br>
<a href="https://www.youtube.com/@MundoMaravilla">Creditos a Mundo Maravilla</a>
<br>
<br>

<h3>Incas</h3>
<br>
<p>Los incas fueron los gobernantes del último gran imperio aborigen de América del Sur y fundadores del estado precolombino de mayor extensión de todo el continente. Su capital era la ciudad sagrada de Cusco, en el actual territorio peruano. Desde allí, dominaron la región hasta su caída frente a los españoles en 1540, quienes encabezados por Francisco Pizarro acabaron con el modo de vida quechua y dieron inicio al Virreinato del Perú. Hubo focos de resistencia incaica (los llamados Incas de Villacabamba) hasta 1572.</p>
<br>
<br>
<p>Los incas fueron los descendientes más tardíos de una de las cunas de la humanidad, ubicada en Norte Chico, entre Chile y Perú. Junto a la mesoamericana, esta fue la expresión originaria humana más importante de América.</p>
<p>Mucha de su cultura pervive todavía, en regiones sudamericanas de importante presencia indígena. También se conserva en relatos y tesoros recuperados durante la época colonial que prosiguió a la conquista.</p>
<br>
<br>                                                                                                                                                                                                                                                                               
<p>Los primeros asentamientos asimilaron por la fuerza a las tribus pre-incaicas de la región, incorporándolas a lo que los incas denominaron el Tawantinsuyu (en quechua “las cuatro partes”), que es como llamaron en su lengua al naciente imperio. Así desarrollaron una poderosa urbe prehispánica que llegó a albergar a varios miles de habitantes.</p>
<p>Según la tradición incaica, el guerrero Manco Cápac fue el organizador y primer regente de los incas en Cuzco, protagonista de uno de los principales mitos fundacionales incaicos, en el cual se le describe a él y a su esposa Mama Ocllo como fruto de la unión en el Lago Titicaca de la diosa Quilla, la Luna, y el dios Inti, el Sol.</p>                                                                                                          
<br>
<br>
<p>En el año 1438, el poderío de los incas se vio desafiado por el reino de los chancas, cuyo líder no veía con buenos ojos la supremacía de la cultura incaica. Los incas lograron repeler la invasión de los chancas y como respuesta emprendieron una expansión a gran escala que continuó de forma ininterrumpida por casi un siglo.</p>
<br>
<br>
<img src="../imagenes/993a51b5ba8d6ccb0988dec79599dfd2.jpeg"width="1286.4px" height="625">
<br>
<br>
<p>El Imperio incaico fue instituido como tal por Pachacútec Inca Yupanqui tras lo sucedido tras la frustrada invasión de los chancas en 1438. Pachacútec era el menor de los hijos del rey Viracocha Inca, soberano de los incas desde 1410. Cuando Viracocha, junto con quien él había nombrado su sucesor, Inca Urco, abandonó Cuzco aceptando la rendición ante los chancas, Pachacútec fue el que defendió la ciudad con las pocas tropas que quedaban. En los años que siguieron, este primer emperador incaico ejerció sus funciones estrechamente con su hijo, Túpac Inca Yupanqui, instruyéndolo en los saberes de la guerra pero dejando de lado los temas relacionados a la administración imperial. Como consecuencia, Túpac se convirtió en un gran líder militar, llegando a ampliar enormemente los dominios del imperio pero incurriendo en el riesgo de la sobreexpansión.</p>
<br>
<br>
<p>La economía y la sociedad incaica se sostenían por medio de una estructura piramidal de jerarquías (castas y clases) en la cual los miembros de la élite redistribuían las riquezas del imperio entre aquellos que les juraran obediencia. A quienes se encotraban en lo más bajo de la pirámide social se les proporcionaba lo suficiente como para sobrevivir, y protección ante agresiones en tanto no quebrantaran ninguna de las tres leyes básicas "Ama Suwa, Ama Llulla, Ama Quella" (no robar, no mentir, no holgazanear). Por otra parte, el Tahuantinsuyo (nombre dado al territorio del imperio) se encontraba sobre una de las mayores reservas de oro y plata del mundo, lo que la llevó a ser una de las civilizaciones más ricas (si no la más rica) del planeta en aquella época.</p>
<br>
<br>
<p>En lugar de confiar en la fuerza bruta o grandes desarrollos tecnológicos, el ejército incaico superaba a sus enemigos mediante efectivas tácticas militares, destacando raudos ataques altamente coordinados, así como también a través de la adaptación de sus tropas a los diversos terrenos del oeste de Sudámerica, lo que resultaba posible gracias a la gran disciplina impartida a sus guerreros.</p>
<br>
<br>
<p>Al enfrentarse a los huancas, los incas emplearon asaltos rápidos para tomarlos por sorpresa y de esa forma evitar un conflicto más largo y dificultoso. Contra el reino Chimú, que se distinguía por contar con los mejores metalurgos de la América precolombina (y posiblemente con las tropas mejor equipadas del Nuevo Mundo antes de la llegada de los europeos), los incas aprovecharon las características desérticas del terreno y cortaron el paso de los ríos que fluían hacia la poderosa capital chimú, Chan Chan, forzando su rendición.</p>
<br>
<br>
<p>El Ejército Inca era un cuerpo multiétnico formado por guerreros de los distintos pueblos que habían conquistado durante su expansión, donde cada uno solía llevar sus propias armas y destrezas al campo de batalla. Es por esto que no era raro para el ejército imperial incaico incluir arqueros amazónicos, honderos andinos, macanas chimúes, lanceros cañaris y espadachines aymará; todos ellos dirigidos por la élite inca como oficiales superiores.</p>
<br>
<br>
<img src="../imagenes/Ejército_Inca_-_Inca_Army.jpg"width="1286.4px" height="625">
<br>
<br>
<p>No existía una marina como entidad militar, aunque las leyendas cuentan acerca de sus barcos de transporte adentrándose en el Océano Pacífico y navegando lejos de sus costas. La evidencia arqueológica indica que las civilizaciones andinas dependían fuertemente del mar para su supervivencia y recientes investigaciones revelan que las provincias más septentrionales del imperio incluso llegaron a comerciar con Mesoamérica.</p>
<br>
<br>
<img src="../imagenes/depositphotos_325468560-stock-photo-the-terraces-or-agricultural-platforms.jpg"width="1286.4px" height="625">
<br>
<br>
<p>En 1479 el ejército del Inca Yupanqui se dirige al sur sometiendo a los pueblos Atacameño y Diaguita. Al cruzar el río Aconcagua y entrar en territorio Araucano, logran derrotar a los Picunches, rama septentrional del pueblo Araucano, estos van retrocediendo batalla tras batalla hasta llegar a la frontera del pueblo Mapuche (rama principal del pueblo Araucano), que es el río Maule. En 1485 tiene lugar la Batalla del Maule, Aquí Picunches y Mapuches enfrentan a los Incas, el resultado es indeciso y ambas facciones se retiran clamando victoria, según las crónicas, los Incas decidieron no avanzar más al sur debido a que "eran tierras pobres y frías" con una constante actividad sísmica (probablemente la principal razón por lo que las tribus originarias del Collasuyo no habían desarrollado construcción de edificaciones), también para evitar una sobre-expansión decidieron asentarse y fundar una ciudad entre los ríos Mapocho y Maipo (lugar elegido con fines defensivos) con el fin de cimentar su cultura a las tribus recientemente anexadas. Otros cronistas de renombre como Felipe Guaman Poma de Ayala menciona que los Incas derrotaron de manera contundente a todos los Pueblos de la Auracanía en una conquista en donde asesinaron a cerca de 100 000 mapuches, esto se complementa con las investigaciones del historiador José Antonio del Busto que relata que Túpac Yupanqui llegó hasta el canal de Chacao, teniendo a la vista la isla Grande de Chiloé, pero volvió al norte porque no veía beneficio alguno en sacrificar hombres conquistando una región que consideraba pobre. Aunque las recientes investigaciones apuntan a que los Incas derrotaron sin contratiempos a los Mapuches, las nuevas interrogantes actuales son la ubicación de la batalla del Maule, le fecha o incluso si la batalla existió realmente; según el historiador Osvaldo Silva Galdames la batalla pudo realmente haber sido una emboscada de un grupo de Mapuches a una expedición de reconocimiento Inca que iba de regreso al norte, la emboscada pudo haber sido cerca del río Maule, río Cachapoal o río Biobío en los años 1471, 1493 o 1532.</p>
<br>
<br>
<p>Alrededor de 1490 Huaynac Cápac fue nombrado el nuevo Sapa Inca del Tawantinsuyo y se dedicó a conquistar los territorios del norte que estaban en parte inexplorados, conquistó a los reinos y pueblos de los actuales Ecuador y Colombia. En este periodo el Imperio Inca intentó incursionar en conquistas hacia la región amazónica, sin embargo, esta campaña fracasó debido a la feroz resistencia del Pueblo Shuar, también conocidos como "Jíbaros", quienes rechazaron a los Incas en 1490 deteniendo la expansión del Tawantinsuyo hacia el Amazonas, los Shuar son un pueblo guerrero que en años posteriores serían considerados como "los únicos nativos de norte y Sudamérica en enfrentarse el poder colonial y vencer".</p>
<br>
<br>
<img src="../imagenes/565456_226829.png"width="1286.4px" height="625" >
<br>
<br>
<p>Durante el gobierno de Huaynac Cápac existieron varias rebeliones en el Tawantinsuyo siendo una de las más conocidas la del Reino de Chachapoyas quienes en sus primeros choques habían hecho retroceder al ejército imperial, también se tuvo que contener las Rebeliones de los huancas y punás. Huaynac Cápac envió a su tío al Collasuyo quién Luego se dirigió a Chile Central, sometiendo definitivamente los valles desde el Río Aconcagua hasta el Río Cachapoal.
<br> 
<br>
<p>En 1522 el Conquistador español Pascual de Andagoya con un un ejército de 2.000 hombres y 22 naves (además de varios indígenas auxiliares de centroamérica) emprendió la primera campaña de conquista del Imperio Inca, la cual concluyó en un estrepitoso fracaso para los conquistadores. Para el año 1527, la "pax incaica" establecida por el emperador Huayna Cápac como un régimen duradero de relativa paz y prosperidad, finalizó con la inesperada muerte de Huayna debido a la viruela; enfermedad desconocida para los incas. La viruela y otras enfermedades traídas por los europeos hicieron estragos en el Imperio inca, matando a buena parte de los habitantes, esta enfermedad fue probablemente propagada por los españoles en su primer intento de conquista del Imperio Inca en 1522. El estado se sumió en una guerra civil en el año 1529, en la coyuntura de un gobierno prácticamente acéfalo, ya que los hijos de Huayna, el príncipe Huáscar y su medio hermano Atahualpa se enfrentaron por el control del imperio. En medio de este caos, Francisco Pizarro junto con un grupo de conquistadores españoles llegaron a Perú con la firme intención de apoderarse de la legendaria riqueza de los incas.</p>
<br>
<br>
<p>El Imperio incaico dejó de existir en el año 1533, cuando el Istyle="z-index: 3; transform: none; user-select: none; touch-action: pan-y;"nca Atahualpa fue capturado por Pizarro y ejecutado a pesar de cumplir con el rescate acordado de dos habitaciones llenas de plata y oro. Tras esto, la facción Inca que apoyó a Huáscar en la guerra civil decidió apoyar a los conquistadores españoles (en particular con los huancas), quienes pactaron proporcionarles la cantidad de soldados necesarios para la campaña, posteriormente los indígenas que apoyaron a los españoles fueron bautizados y los integraron al Imperio Español.</p>
<br>
<br>
<p>Sin embargo, la civilización incaica continuó existiendo hasta 1572 con los Incas de Vilcabamba comandados por Manco Inca Yupanqui; en parte gracias a las permanentes disputas internas entre los conquistadores españoles. Manco Inca es conocido por organizar el Cerco de Lima y el Sitio de Cuzco (1536-1537), en la cuál derrotó a un ejército de 3,000 soldados españoles y 10,000 tropas auxiliares de indígenas (Yanaconas) que fueron enviados de Lima a apoyar la resistencia de Cuzco. Manco Inca es considerado el primer Nativo Americano en formar un ejército con armas europeas de la época (caballería, artillería, armas de fuego, armas y armaduras de acero), posteriormente al asedio se originaron grandes batallas de resistencia incaica como la batalla de Ollantaytambo, durante las siguientes décadas Manco Inca dirigió una guerra de guerrillas contra los españoles desde su fortaleza en Vilcabamba en la cual contaba con el apoyo del "Antisuyo", la región del Tahuantinsuyo formado por las etnias de la selva amazónica, que se cree que durante la rebelión de Manco Inca Yupanqui controlaban aproximadamente 1/3 del territorio de lo que fue el Imperio Inca. A pesar de los posteriores intentos de recrear el caído imperio, nunca más una civilización andina liderada por pueblos originarios logró reconquistar la antigua gloria de los incas.</p>
<br>
<br>
</div>
</div>
<?php
}
?>

<section>


    <div id="carouselExampleCaptions" class="carousel slide">
        <div class="carousel-indicators">
          <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
          <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2"></button>
          <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2" aria-label="Slide 3"></button>
        </div>
        <div class="carousel-inner">
          <div class="carousel-item active">
            <img src="..." class="d-block w-100" width="1046.4px"height="600">
            <div class="carousel-caption d-none d-md-block">
              <h5>First slide label￼</h5>
              <p>Some representative placeholder content for the first slide.</p>
            </div>
          </div>
          <div class="carousel-item">
            <img src="..." class="d-block w-100" width="1046.4px"height="600">
            <div class="carousel-caption d-none d-md-block">
              <h5>Second slide label</h5>
              <p>Some representative placeholder content for the second slide.</p>
            </div>
          </div>
          <div class="carousel-item">
            <img src="..." class="d-block w-100" width="1046.4px"height="600">
            <div class="carousel-caption d-none d-md-block">
              <h5>Third slide label</h5>
              <p>Med.</p>
            </div>
        </div>
      </div>
      <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Previous</span>
      </button>
      <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Next</span>
      </button>
    </div>



</section>
</div>


<div class="texto5">
  <h2>Lo más buscado</h2>
  <div class = "li">
<ul>
  <div class="textoP">
      <li><span><a href="CivilizacionesAmerica.html"><p>1- Civilizaciones de America</p></a></span></li>
      <br>
      <li><span><a href="CivilizacionesAmerica.html"><p>2- Civilizaciones de America</p></a></span></li>
      <br>
      <li><span><a href="CivilizacionesAmerica.html"><p>3- Civilizaciones de America</p></a></span></li>
      <br>
      <li><span><a href="CivilizacionesAmerica.html"><p>4- Civilizaciones de America</p></a></span></li>
     
        </div>
        
        <div class="textoP">
    
      <span><a href="CivilizacionesAmerica.html"><p>5- Civilizaciones de America</p></a></span>
      <br>
      <span><a href="CivilizacionesAmerica.html"><p>6- Civilizaciones de America</p></a></span>
      <br>
      <span><a href="CivilizacionesAmerica.html"><p>7- Civilizaciones de America</p></a></span>
      <br>
      <span><a href="CivilizacionesAmerica.html"><p>8- Civilizaciones de America</p></a></span></div>
      <br>
      
</div>


  </ul>
  </div>
  

</section>
</div>



  
<div class="linea1">
</div>
<footer class="footer">
<div class="texto3">
<h2>Contactos:</h2>
</div>
<div class="imagenes2"><img src="../imagenes/Gmail_icon_(2020).svg.png" width="65px" height="50px">
</div>
<div class="doblepunto"><p>:</p>
</div>
<div class="texto4"><a href="https://www.youtube.com/watch?v=nq6_77PSV-Y&ab_channel=VSP7FOOTBALLEXTRA"><p>Gmail</p></a>
</div>
<div class="imagenes2"><img src="../imagenes/descarga.jpeg" width="75px" height="50px">
</div>
<div class="doblepunto"><p>:</p>
</div>
<div class="texto4"><a href="https://www.youtube.com/watch?v=nq6_77PSV-Y&ab_channel=VSP7FOOTBALLEXTRA"><p>Twiter</p></a>
</div>
<div class="imagenes2"><img src="../imagenes/Instagram_logo_2016.svg.webp" width="55px" height="50px">
</div>
<div class="doblepunto"><p>:</p>
</div>
<div class="texto4"><a href="https://www.youtube.com/watch?v=nq6_77PSV-Y&ab_channel=VSP7FOOTBALLEXTRA"><p>Instagram</p></a>
</div>
<div class="imagenes2"><img src="../imagenes/Youtube_logo.png" width="75px" height="50px">
</div>
<div class="doblepunto"><p>:</p>
</div>
<div class="texto4"><a href="https://www.youtube.com/watch?v=nq6_77PSV-Y&ab_channel=VSP7FOOTBALLEXTRA"><p>Youtube</p></a>
</div>


</footer>
    </body>
</html>












